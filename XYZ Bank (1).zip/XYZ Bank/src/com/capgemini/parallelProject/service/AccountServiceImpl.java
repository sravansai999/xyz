package com.capgemini.parallelProject.service;

import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.parallelProject.bean.Account;
import com.capgemini.parallelProject.bean.Transaction;
import com.capgemini.parallelProject.dao.AccountDao;
import com.capgemini.parallelProject.dao.AccountDaoImpl;
import com.capgemini.parallelProject.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	
	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public boolean validateName(String name) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{4,}";

		if (!Pattern.matches(nameRegEx, name)) {
			throw new AccountException("first letter should be capital and length should be gt 5");
		} else {
			resultFlag = true;
		}
		return resultFlag;
	}

	@Override
	public boolean validateNumber(String mobileNo) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String mobile = String.valueOf(mobileNo);
		Pattern nameptn = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match = nameptn.matcher(mobile);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("first letter should be between 7-9 and the length should be 10");
		}
		return false;
	}

	/*@Override
	public boolean validateAccountNumber(long accountNo) throws AccountException {
		// TODO Auto-generated method stub
		boolean resultFlag = false;
		String number = String.valueOf(accountNo);
		Pattern nameptn = Pattern.compile("^[0-9]{7}$");
		Matcher match = nameptn.matcher(number);
		if (match.matches()) {
			resultFlag=true;
		}
		else {
			throw new AccountException("Account number should contain only numbers and its length should be 7");
		}
		return false;
	}*/

	@Override
	public boolean validateAmount(double amount) throws AccountException {
		// TODO Auto-generated method stub
		boolean amountFlag = false;

		if (amount < 500) {
			throw new AccountException("cost should not be lt 0");
		} else {
			amountFlag = true;
		}
		return amountFlag;
	}

	@Override
	public long generateId() throws AccountException {
		// TODO Auto-generated method stub
				long accountNo =(long) (Math.random() * 100000000L); 
				return accountNo;
	}

	@Override
	public void addAccount(long accountNo, Account account) {
		// TODO Auto-generated method stub
		accountDao.addAccount(accountNo,account);	
	}

	@Override
	public long deposit(long accNo, long amountDeposited) throws AccountException {
		// TODO Auto-generated method stub
		return accountDao.deposit(accNo, amountDeposited);
	}

	@Override
	public long withdrawl(long accountNo, long amountWithdrawl) throws AccountException {
		// TODO Auto-generated method stub
		return accountDao.withdrawl(accountNo, amountWithdrawl);
	}

	@Override
	public long addTransaction(long senderAccountNo, long recieverAccountNo, long transferAmount) throws AccountException{
		// TODO Auto-generated method stub
		return accountDao.transaction(senderAccountNo, recieverAccountNo, transferAmount);
	}

	@Override
	public long getBalance(long accountNo) {
		// TODO Auto-generated method stub
		return accountDao.getBalance(accountNo);
	}

	@Override
	public int transacId() {
		// TODO Auto-generated method stub
		int transactionId =(int) (Math.random() * 1000); 
		return transactionId;
	}

	@Override
	public boolean addTransaction(Transaction transaction) throws AccountException {
		// TODO Auto-generated method stub
		accountDao.addTraansaction(transaction);
		return true;
	}

	@Override
	public Set<Transaction> printTransaction()throws AccountException{
		// TODO Auto-generated method stub
		return accountDao.printTransaction();
	}

	

	

	

	

}
